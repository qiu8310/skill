## [: hidden :]

### 创建帐户

填写注册课程所需的个人信息

> 注册
>
> **用户体验的研究与策略**
>
>  价格 ¥500 （12月10日课程开始后，才会收取费用）


### [: form hidden :]

* [: control input email :] 请输入你的邮箱地址
* [: control input username :] 请输入你的真实姓名
* [: control button submit :] 提交


## 本次 **4周在线课程** 包括:

![图片](https://d1ijjxzthis87e.cloudfront.net/static/store/images/skype-icon@2x.png)

**1:1 实时交流**

通过微信定期和导师进行交流，导师也会检查你的学习情况



![图片](https://d1ijjxzthis87e.cloudfront.net/static/store/images/projects-icon@2x.png)

**项目实战**

通过超过 **20 小时**  的专题学习来强化设计原则



![图片](https://d1ijjxzthis87e.cloudfront.net/static/store/images/feedback-icon@2x.png)

**在线反馈**

会有专家级的设计师进行及时的、专业水准的反馈
