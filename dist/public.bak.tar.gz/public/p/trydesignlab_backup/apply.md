## [: hidden :]

### Create your account

Enter your info for a new Designlab account

> Signing up for
>
> **UX Research & Strategy**
>
> for $399


### [: form hidden :]

* [: control input email :] 请输入你的邮箱地址
* [: control input username :] 请输入你的真实姓名
* [: control button submit :] 提交


## This **4-week online course** includes:

![图片](https://d1ijjxzthis87e.cloudfront.net/static/store/images/skype-icon@2x.png)

**1:1 Skype Sessions**

Meet regularly with your personal mentor to discuss concepts & go over your work.



![图片](https://d1ijjxzthis87e.cloudfront.net/static/store/images/projects-icon@2x.png)

**Hands-on Projects**

Learn by doing with over **20 hours** of project work to reinforce design principles.



![图片](https://d1ijjxzthis87e.cloudfront.net/static/store/images/feedback-icon@2x.png)

**Online Feedback**

Get timely, annotated feedback on your projects from an expert designer.
